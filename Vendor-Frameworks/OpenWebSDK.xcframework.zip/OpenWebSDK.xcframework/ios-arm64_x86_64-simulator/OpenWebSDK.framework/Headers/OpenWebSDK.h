//
//  OpenWebSDK.h
//  OpenWebSDK
//
//  Created by Eugene on 23.10.2019.
//  Copyright © 2019 OpenWeb. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SpotImCore.
FOUNDATION_EXPORT double OpenWebSDKVersionNumber;

//! Project version string for SpotImCore.
FOUNDATION_EXPORT const unsigned char OpenWebSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpotImCore/PublicHeader.h>
